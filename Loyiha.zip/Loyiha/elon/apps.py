from django.apps import AppConfig


class ElonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'elon'
