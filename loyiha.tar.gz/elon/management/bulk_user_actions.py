"""
Django management command - Foydalanuvchilarni ommaviy boshqarish

Foydalanish:
python manage.py bulk_user_actions --activate-all
python manage.py bulk_user_actions --deactivate-inactive
python manage.py bulk_user_actions --cleanup-old-users
python manage.py bulk_user_actions --stats
"""

from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from datetime import timedelta

class Command(BaseCommand):
    help = 'Foydalanuvchilarni ommaviy boshqarish uchun buyruqlar'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--activate-all',
            action='store_true',
            help='Barcha foydalanuvchilarni faollashtirish',
        )
        parser.add_argument(
            '--deactivate-inactive',
            action='store_true',
            help='30+ kun davomida kirmagan foydalanuvchilarni nofaol qilish',
        )
        parser.add_argument(
            '--cleanup-old-users',
            action='store_true',
            help='6 oy davomida nofaol foydalanuvchilarni o\'chirish',
        )
        parser.add_argument(
            '--stats',
            action='store_true',
            help='Foydalanuvchilar statistikasini ko\'rsatish',
        )
        parser.add_argument(
            '--inactive-days',
            type=int,
            default=30,
            help='Necha kun nofaol bo\'lgan foydalanuvchilarni deaktiv qilish (default: 30)',
        )
        parser.add_argument(
            '--cleanup-days',
            type=int,
            default=180,
            help='Necha kun nofaol bo\'lgan foydalanuvchilarni o\'chirish (default: 180)',
        )
    
    def handle(self, *args, **options):
        # Statistikalarni ko'rsatish
        if options['stats']:
            self.show_stats()
            return
        
        # Barcha foydalanuvchilarni faollashtirish
        if options['activate_all']:
            self.activate_all_users()
        
        # Nofaol foydalanuvchilarni deaktiv qilish
        if options['deactivate_inactive']:
            self.deactivate_inactive_users(options['inactive_days'])
        
        # Eski foydalanuvchilarni o'chirish
        if options['cleanup_old_users']:
            self.cleanup_old_users(options['cleanup_days'])
    
    def show_stats(self):
        """Foydalanuvchilar statistikasini ko'rsatish"""
        self.stdout.write(self.style.HTTP_INFO('=== FOYDALANUVCHILAR STATISTIKASI ==='))
        
        total_users = User.objects.count()
        active_users = User.objects.filter(is_active=True).count()
        inactive_users = User.objects.filter(is_active=False).count()
        staff_users = User.objects.filter(is_staff=True).count()
        superusers = User.objects.filter(is_superuser=True).count()
        
        # Vaqt bo'yicha statistikalar
        week_ago = timezone.now() - timedelta(days=7)
        month_ago = timezone.now() - timedelta(days=30)
        
        new_week = User.objects.filter(date_joined__gte=week_ago).count()
        new_month = User.objects.filter(date_joined__gte=month_ago).count()
        never_logged = User.objects.filter(last_login__isnull=True).count()
        
        self.stdout.write(f'Jami foydalanuvchilar: {total_users}')
        self.stdout.write(f'Faol foydalanuvchilar: {active_users}')
        self.stdout.write(f'Nofaol foydalanuvchilar: {inactive_users}')
        self.stdout.write(f'Staff foydalanuvchilar: {staff_users}')
        self.stdout.write(f'Super adminlar: {superusers}')
        self.stdout.write(f'Haftalik yangilar: {new_week}')
        self.stdout.write(f'Oylik yangilar: {new_month}')
        self.stdout.write(f'Hech qachon kirmagan: {never_logged}')
    
    def activate_all_users(self):
        """Barcha foydalanuvchilarni faollashtirish"""
        inactive_users = User.objects.filter(is_active=False)
        count = inactive_users.count()
        
        if count == 0:
            self.stdout.write(
                self.style.WARNING('Faollashtirilishi kerak bo\'lgan foydalanuvchi topilmadi.')
            )
            return
        
        # Tasdiqlash
        if input(f'{count} ta foydalanuvchini faollashtirishni xohlaysizmi? (y/N): ').lower() != 'y':
            self.stdout.write(self.style.WARNING('Bekor qilindi.'))
            return
        
        updated = inactive_users.update(is_active=True)
        self.stdout.write(
            self.style.SUCCESS(f'{updated} ta foydalanuvchi faollashtirildi.')
        )
    
    def deactivate_inactive_users(self, inactive_days):
        """Nofaol foydalanuvchilarni deaktiv qilish"""
        cutoff_date = timezone.now() - timedelta(days=inactive_days)
        
        # Hech qachon kirmagan va eski foydalanuvchilarni topish
        inactive_users = User.objects.filter(
            last_login__isnull=True,
            date_joined__lt=cutoff_date,
            is_active=True,
            is_staff=False,  # Staff'larni deaktiv qilmaslik
            is_superuser=False  # Superuser'larni deaktiv qilmaslik
        )
        
        count = inactive_users.count()
        
        if count == 0:
            self.stdout.write(
                self.style.WARNING(f'{inactive_days} kun davomida nofaol foydalanuvchi topilmadi.')
            )
            return
        
        # Ma'lumot ko'rsatish
        self.stdout.write(f'{inactive_days} kun davomida nofaol foydalanuvchilar:')
        for user in inactive_users[:10]:  # Faqat birinchi 10 tasini ko'rsatish
            self.stdout.write(f'  - {user.username} ({user.email}) - {user.date_joined.date()}')
        
        if count > 10:
            self.stdout.write(f'  ... va yana {count - 10} ta')
        
        # Tasdiqlash
        if input(f'{count} ta foydalanuvchini nofaol qilishni xohlaysizmi? (y/N): ').lower() != 'y':
            self.stdout.write(self.style.WARNING('Bekor qilindi.'))
            return
        
        updated = inactive_users.update(is_active=False)
        self.stdout.write(
            self.style.SUCCESS(f'{updated} ta foydalanuvchi nofaol qilindi.')
        )
    
    def cleanup_old_users(self, cleanup_days):
        """Eski nofaol foydalanuvchilarni o'chirish"""
        cutoff_date = timezone.now() - timedelta(days=cleanup_days)
        
        # Eski, nofaol va hech qachon kirmagan foydalanuvchilar
        old_users = User.objects.filter(
            is_active=False,
            last_login__isnull=True,
            date_joined__lt=cutoff_date,
            is_staff=False,  # Staff'larni o'chirmaslik
            is_superuser=False  # Superuser'larni o'chirmaslik
        )
        
        count = old_users.count()
        
        if count == 0:
            self.stdout.write(
                self.style.WARNING(f'{cleanup_days} kun davomida nofaol foydalanuvchi topilmadi.')
            )
            return
        
        # Ma'lumot ko'rsatish
        self.stdout.write(f'{cleanup_days} kun davomida nofaol foydalanuvchilar (o\'chiriladi):')
        for user in old_users[:10]:  # Faqat birinchi 10 tasini ko'rsatish
            self.stdout.write(f'  - {user.username} ({user.email}) - {user.date_joined.date()}')
        
        if count > 10:
            self.stdout.write(f'  ... va yana {count - 10} ta')
        
        # Xavfli amaliyot uchun qo'shimcha ogohlantirish
        self.stdout.write(
            self.style.ERROR('OGOHLANTIRISH: Bu amaliyot qaytarib bo\'lmaydigan!')
        )
        
        # Tasdiqlash
        confirm_text = input(f'{count} ta foydalanuvchini o\'chirishni xohlaysizmi? Tasdiqlash uchun "DELETE" deb yozing: ')
        if confirm_text != 'DELETE':
            self.stdout.write(self.style.WARNING('Bekor qilindi.'))
            return
        
        # O'chirish
        deleted_count = old_users.count()
        old_users.delete()
        
        self.stdout.write(
            self.style.SUCCESS(f'{deleted_count} ta eski foydalanuvchi o\'chirildi.')
        )
        
        # Log yozish (ixtiyoriy)
        self.stdout.write(
            self.style.HTTP_INFO(f'O\'chirilgan foydalanuvchilar soni: {deleted_count}')
        )