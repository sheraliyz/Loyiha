document.addEventListener('DOMContentLoaded', function() {
    const overlay = document.createElement('div');
    overlay.className = 'loading-overlay';
    overlay.innerHTML = '<div class="loading-spinner"></div>';
    document.body.appendChild(overlay);

    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function() {
            overlay.style.display = 'flex';
        });
    });

    document.querySelectorAll('a[href]').forEach(link => {
        if (link.href.includes('#') || link.href.includes('javascript:') || link.classList.contains('no-loading')) {
            return;
        }
        link.addEventListener('click', function() {
            overlay.style.display = 'flex';
        });
    });

    window.addEventListener('load', function() {
        overlay.style.display = 'none';
    });
});