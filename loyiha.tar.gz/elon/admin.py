# elon/admin.py
from django.contrib import admin
from django.contrib.auth.models import User
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from django.urls import path
from django.shortcuts import render
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.utils import timezone
from datetime import timedelta

# Kengaytirilgan User Admin
class UserAdmin(BaseUserAdmin):
    list_display = (
        'username', 'email', 'first_name', 'last_name', 
        'date_joined', 'last_login', 'is_active', 
        'is_staff', 'is_superuser', 'colored_status'
    )
    list_filter = (
        'is_active', 'is_staff', 'is_superuser', 
        'date_joined', 'last_login'
    )
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)
    
    # Custom fieldsets
    fieldsets = BaseUserAdmin.fieldsets
    readonly_fields = ('date_joined', 'last_login')
    
    # Custom actions
    actions = ['make_active', 'make_inactive', 'make_staff', 'remove_staff']
    
    def colored_status(self, obj):
        """Rangli status ko'rsatish"""
        if obj.is_superuser:
            return format_html(
                '<span style="color: #dc3545; font-weight: bold;">Super Admin</span>'
            )
        elif obj.is_staff:
            return format_html(
                '<span style="color: #fd7e14; font-weight: bold;">Staff</span>'
            )
        elif obj.is_active:
            return format_html(
                '<span style="color: #198754;">Faol</span>'
            )
        else:
            return format_html(
                '<span style="color: #6c757d;">Nofaol</span>'
            )
    
    colored_status.short_description = 'Status'
    
    def make_active(self, request, queryset):
        """Foydalanuvchilarni faollashtirish"""
        updated = queryset.update(is_active=True)
        self.message_user(
            request, 
            f'{updated} ta foydalanuvchi faollashtirildi.',
            messages.SUCCESS
        )
    make_active.short_description = "Tanlangan foydalanuvchilarni faollashtirish"
    
    def make_inactive(self, request, queryset):
        """Foydalanuvchilarni nofaol qilish"""
        updated = queryset.update(is_active=False)
        self.message_user(
            request, 
            f'{updated} ta foydalanuvchi nofaol qilindi.',
            messages.SUCCESS
        )
    make_inactive.short_description = "Tanlangan foydalanuvchilarni nofaol qilish"
    
    def make_staff(self, request, queryset):
        """Staff huquqi berish"""
        updated = queryset.update(is_staff=True)
        self.message_user(
            request, 
            f'{updated} ta foydalanuvchi staff qilindi.',
            messages.SUCCESS
        )
    make_staff.short_description = "Tanlangan foydalanuvchilarni staff qilish"
    
    def remove_staff(self, request, queryset):
        """Staff huquqini olish"""
        updated = queryset.update(is_staff=False)
        self.message_user(
            request, 
            f'{updated} ta foydalanuvchidan staff huquqi olib tashlandi.',
            messages.SUCCESS
        )
    remove_staff.short_description = "Tanlangan foydalanuvchilardan staff huquqini olish"


# Dashboard view
@staff_member_required
def admin_dashboard(request):
    """Custom admin dashboard"""
    try:
        # Statistikalar
        total_users = User.objects.count()
        active_users = User.objects.filter(is_active=True).count()
        staff_users = User.objects.filter(is_staff=True).count()
        superusers = User.objects.filter(is_superuser=True).count()
        
        # Vaqt statistikalari
        week_ago = timezone.now() - timedelta(days=7)
        month_ago = timezone.now() - timedelta(days=30)
        day_ago = timezone.now() - timedelta(days=1)
        
        new_users_week = User.objects.filter(date_joined__gte=week_ago).count()
        new_users_month = User.objects.filter(date_joined__gte=month_ago).count()
        active_today = User.objects.filter(last_login__gte=day_ago).count()
        
        # Top foydalanuvchilar
        most_active = User.objects.filter(
            is_active=True, 
            last_login__isnull=False
        ).order_by('-last_login')[:10]
        
        newest_users = User.objects.filter(
            is_active=True
        ).order_by('-date_joined')[:10]
        
        inactive_users = User.objects.filter(is_active=False).count()
        never_logged_in = User.objects.filter(last_login__isnull=True).count()
        
        context = {
            'title': 'Foydalanuvchilar Dashboard',
            'total_users': total_users,
            'active_users': active_users,
            'inactive_users': inactive_users,
            'staff_users': staff_users,
            'superusers': superusers,
            'new_users_week': new_users_week,
            'new_users_month': new_users_month,
            'active_today': active_today,
            'never_logged_in': never_logged_in,
            'most_active': most_active,
            'newest_users': newest_users,
        }
        
        return render(request, 'admin/users_dashboard.html', context)
        
    except Exception as e:
        messages.error(request, f'Dashboard xatolik: {str(e)}')
        # Oddiy context bilan qaytarish
        return render(request, 'admin/users_dashboard.html', {
            'title': 'Dashboard',
            'error': True
        })


# User modelni qayta ro'yxatga olish
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass
admin.site.register(User, UserAdmin)

# Admin site sozlamalari
admin.site.site_header = "Yourrule Admin Panel"
admin.site.site_title = "Yourrule Admin"
admin.site.index_title = "Boshqaruv paneli"

# Agar sizning elon modellaringiz bo'lsa, ularni ham qo'shing
# from .models import YourModel
# 
# @admin.register(YourModel)
# class YourModelAdmin(admin.ModelAdmin):
#     list_display = ['name', 'created_at']
#     list_filter = ['created_at']
#     search_fields = ['name']