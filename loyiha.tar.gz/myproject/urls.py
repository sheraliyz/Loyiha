# myproject/urls.py (asosiy URLs)
"""
URL configuration for myproject project.
"""
from django.contrib import admin
from django.urls import path, include
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.contrib.auth import logout, authenticate, login
from django.contrib.auth.models import User
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
from django.conf.urls.static import static
import json

from elon import views as elon_views
from elon.admin import admin_dashboard
from elon.views import users_dashboard
handler404 = 'elon.views.custom_404'
handler500 = 'elon.views.custom_500'
def home(request):
    """
    Eski home view - yangi home_view ishlatiladi
    """
    return redirect('home')

def login_view(request):
    from elon.models import Profile
    if request.method == 'POST':
        identifier = request.POST.get('identifier')
        password = request.POST.get('password')
        user = authenticate(request, username=identifier, password=password)
        
        if user is None:
            # Email orqali kirish urinishi
            try:
                user_obj = User.objects.get(email=identifier)
                user = authenticate(request, username=user_obj.username, password=password)
            except User.DoesNotExist:
                user = None
        
        if user is not None:
            # Profile yaratish
            Profile.objects.get_or_create(user=user)
            login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html', {'error': "Username/email yoki parol noto'g'ri."})
    
    return render(request, 'login.html')

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        
        if password != password2:
            return render(request, 'register.html', {'error': 'Parollar mos emas.'})
        
        if User.objects.filter(username=username).exists():
            return render(request, 'register.html', {'error': "Bu username allaqachon ro'yxatdan o'tgan."})
        
        if User.objects.filter(email=email).exists():
            return render(request, 'register.html', {'error': "Bu email allaqachon ro'yxatdan o'tgan."})
        
        user = User.objects.create_user(username=username, email=email, password=password)
        user.backend = 'django.contrib.auth.backends.ModelBackend'
        login(request, user, backend='django.contrib.auth.backends.ModelBackend')
        return redirect('home')
    
    return render(request, 'register.html')

def logout_view(request):
    if request.method == 'POST':
        logout(request)
        return redirect('home')
    from django.http import HttpResponseNotAllowed
    return HttpResponseNotAllowed(['POST'])

def users_info(request):
    if not request.user.is_superuser:
        return JsonResponse({'error': 'Forbidden'}, status=403)
    
    users = list(User.objects.all().values('id', 'username', 'email', 'date_joined', 'is_active'))
    total = len(users)
    active = sum(1 for u in users if u['is_active'])
    
    for u in users:
        u['date_joined'] = u['date_joined'].strftime('%Y-%m-%d %H:%M')
    
    return JsonResponse({'users': users, 'total': total, 'active': active})

@csrf_exempt
def users_info_delete(request, id):
    if not request.user.is_superuser or request.method != 'POST':
        return JsonResponse({'msg': 'Forbidden'}, status=403)
    
    try:
        user = User.objects.get(id=id)
        if user.is_superuser:
            return JsonResponse({'msg': "Superuserni o'chirish mumkin emas!"}, status=400)
        user.delete()
        return JsonResponse({'msg': "Foydalanuvchi o'chirildi."})
    except User.DoesNotExist:
        return JsonResponse({'msg': 'Foydalanuvchi topilmadi.'}, status=404)

@csrf_exempt
def users_info_password(request, id):
    if not request.user.is_superuser or request.method != 'POST':
        return JsonResponse({'msg': 'Forbidden'}, status=403)
    
    try:
        user = User.objects.get(id=id)
        data = json.loads(request.body)
        user.set_password(data.get('password'))
        user.save()
        return JsonResponse({'msg': 'Parol o\'zgartirildi.'})  # Quote xatosi tuzatildi
    except User.DoesNotExist:
        return JsonResponse({'msg': 'Foydalanuvchi topilmadi.'}, status=404)

def profile_edit(request):
    from elon.models import Profile
    if not request.user.is_authenticated:
        return redirect('login')
    
    profile, created = Profile.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        avatar = request.FILES.get('avatar')
        if avatar:
            profile.avatar = avatar
            profile.save()
        return redirect('home')
    
    return render(request, 'profile_edit.html', {'profile': profile})

def developers_view(request):
    return render(request, 'developers.html')

# URL Patterns
urlpatterns = [
    # Bosh sahifa - yangi statistikalar bilan
    path('', elon_views.home_view, name='home'),
    
    # Auth URL'lari
    path('login/', login_view, name='login'),
    path('register/', register_view, name='register'),
    path('logout/', logout_view, name='logout'),
    path('profile/edit/', profile_edit, name='profile_edit'),
    
    # Social auth (agar ishlatilsa)
    path('auth/', include('social_django.urls', namespace='social')),
    
    # Admin paneli
    path('admin/', admin.site.urls),
    path('admin/dashboard/', admin_dashboard, name='admin_dashboard'),
    path('admin/users-dashboard/', users_dashboard, name='users_dashboard'),
    path('admin-stats/', elon_views.admin_stats_api, name='admin_stats_api'),
    
    # Foydalanuvchilar boshqaruvi (Admin uchun)
    path('api/users-info/', users_info, name='users_info'),
    path('api/users-info/delete/<int:id>/', users_info_delete, name='users_info_delete'),
    path('api/users-info/password/<int:id>/', users_info_password, name='users_info_password'),
    
    # E'lonlar bo'limi
    path('elons/', elon_views.elon_list, name='elon_list'),
    path('elons/create/', elon_views.elon_create, name='elon_create'),
    path('elons/<int:id>/', elon_views.elon_detail, name='elon_detail'),
    path('elons/<int:id>/edit/', elon_views.elon_edit, name='elon_edit'),
    path('elons/<int:id>/delete/', elon_views.elon_delete, name='elon_delete'),
    path('elons/<int:id>/comment/', elon_views.add_comment, name='add_comment'),
    path('my-elons/', elon_views.my_elons, name='my_elons'),
    
    # Xizmatlar bo'limi
    path('xizmatlar/', elon_views.xizmatlar_list, name='xizmatlar_list'),
    path('xizmatlar/qoshish/', elon_views.xizmat_qoshish, name='xizmat_qoshish'),
    path('xizmatlar/<int:id>/tahrir/', elon_views.xizmat_tahrir, name='xizmat_tahrir'),
    path('xizmatlar/<int:id>/ochirish/', elon_views.xizmat_ochirish, name='xizmat_ochirish'),
    
    # Boshqa sahifalar
    path('developers/', developers_view, name='developers'),
    
    # App URL'larini include qilish (agar alohida app URLs bo'lsa)
    # path('elon/', include('elon.urls')),  # Uncommnet qiling agar kerak bo'lsa
]

# Static va Media fayllar
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


# ===========================================
# elon/urls.py (App-level URLs) - Agar alohida kerak bo'lsa
# ===========================================

"""
# elon/urls.py
from django.urls import path
from . import views

app_name = 'elon'

urlpatterns = [
    # E'lonlar
    path('', views.elon_list, name='list'),
    path('create/', views.elon_create, name='create'),
    path('<int:id>/', views.elon_detail, name='detail'),
    path('<int:id>/edit/', views.elon_edit, name='edit'),
    path('<int:id>/delete/', views.elon_delete, name='delete'),
    path('<int:id>/comment/', views.add_comment, name='add_comment'),
    path('my/', views.my_elons, name='my_elons'),
    
    # Xizmatlar
    path('xizmatlar/', views.xizmatlar_list, name='xizmatlar_list'),
    path('xizmatlar/qoshish/', views.xizmat_qoshish, name='xizmat_qoshish'),
    path('xizmatlar/<int:id>/tahrir/', views.xizmat_tahrir, name='xizmat_tahrir'),
    path('xizmatlar/<int:id>/ochirish/', views.xizmat_ochirish, name='xizmat_ochirish'),
]
"""