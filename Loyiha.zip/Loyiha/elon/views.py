from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Elon, Comment, Service
from django.http import HttpResponseForbidden, JsonResponse
from django.utils import timezone
import pytz
from django.views.decorators.http import require_POST
from django.urls import reverse
from django.contrib import messages
from django.contrib.auth.decorators import user_passes_test
from django import forms
from django.contrib.auth.models import User
from django.db.models import Count, Q
from datetime import timedelta
from django.contrib.admin.views.decorators import staff_member_required
from django.core.paginator import Paginator

UZ_TZ = pytz.timezone('Asia/Tashkent')
from django.shortcuts import render

def custom_404(request, exception):
    return render(request, '404.html', status=404)

def custom_500(request):
    return render(request, '500.html', status=500)
# Bosh sahifa view'i
def home_view(request):
    """
    Bosh sahifa uchun view - statistikalarni hisoblaydi
    """
    # Jami e'lonlar soni
    try:
        total_elons = Elon.objects.count()
    except:
        total_elons = 0

    # Faol foydalanuvchilar (oxirgi 30 kun ichida kirgan)
    thirty_days_ago = timezone.now() - timedelta(days=30)
    try:
        active_users = User.objects.filter(
            Q(last_login__gte=thirty_days_ago) | Q(date_joined__gte=thirty_days_ago)
        ).count()
    except:
        active_users = User.objects.count()

    # Xizmatlar soni
    try:
        total_services = Service.objects.count()
    except:
        total_services = 0

    # Jami foydalanuvchilar
    try:
        total_users = User.objects.count()
    except:
        total_users = 0

    context = {
        'total_elons': total_elons,
        'active_users': active_users,
        'total_services': total_services,
        'total_users': total_users,
    }
    return render(request, 'home.html', context)

@staff_member_required
def users_dashboard(request):
    return render(request, 'admin/users_dashboard.html')

# Admin statistikalari API
@staff_member_required
def admin_stats_api(request):
    """
    Admin uchun AJAX orqali statistikalar
    """
    # Jami foydalanuvchilar
    total_users = User.objects.count()

    # Yangi foydalanuvchilar (oxirgi 7 kun)
    week_ago = timezone.now() - timedelta(days=7)
    new_users = User.objects.filter(date_joined__gte=week_ago).count()

    # Faol foydalanuvchilar (oxirgi 24 soat)
    day_ago = timezone.now() - timedelta(days=1)
    active_today = User.objects.filter(last_login__gte=day_ago).count()

    # Superuser'lar soni
    superusers_count = User.objects.filter(is_superuser=True).count()

    # Staff user'lar soni
    staff_count = User.objects.filter(is_staff=True).count()

    # E'lonlar statistikasi
    total_elons = Elon.objects.count()
    week_elons = Elon.objects.filter(created_at__gte=week_ago).count()

    # Xizmatlar statistikasi
    total_services = Service.objects.count()

    data = {
        'total_users': total_users,
        'new_users_week': new_users,
        'active_today': active_today,
        'superusers': superusers_count,
        'staff_users': staff_count,
        'total_elons': total_elons,
        'week_elons': week_elons,
        'total_services': total_services,
    }
    return JsonResponse(data)

# Context processor (agar barcha sahifalarda statistik ma'lumot kerak bo'lsa)
def stats_context_processor(request):
    """
    Barcha template'larda foydalanish uchun context processor
    """
    return {
        'site_stats': {
            'total_users': User.objects.count(),
            'active_users': User.objects.filter(
                last_login__gte=timezone.now() - timedelta(days=30)
            ).count(),
        }
    }

# E'lonlar ro'yxati - Yangilangan versiya qidiruv, filter va pagination bilan
@login_required
def elon_list(request):
    """
    E'lonlar ro'yxati - qidiruv, kategoriya filter, tartiblash va sahifalash bilan
    """
    # Barcha e'lonlarni olish
    elons = Elon.objects.all()
    
    # Qidiruv
    search_query = request.GET.get('search', '')
    if search_query:
        elons = elons.filter(
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(user__username__icontains=search_query)
        )
    
    # Kategoriya bo'yicha filtr
    category = request.GET.get('category', '')
    if category:
        elons = elons.filter(category=category)
    
    # Tartiblash
    sort_by = request.GET.get('sort', '-created_at')
    valid_sort_fields = ['-created_at', 'created_at', 'title', '-title']
    if sort_by in valid_sort_fields:
        elons = elons.order_by(sort_by)
    else:
        elons = elons.order_by('-created_at')
    
    # Vaqtni O'zbekiston vaqtiga o'tkazish
    for elon in elons:
        elon.created_at_uz = elon.created_at.astimezone(UZ_TZ)
    
    # Sahifalash (Pagination)
    paginator = Paginator(elons, 6)  # Har sahifada 6 ta e'lon
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Kategoriyalar ro'yxati (select uchun)
    categories = [
        ('gamer', 'Gamer'),
        ('developer', 'Dasturchi'),
        ('other', 'Boshqa'),
    ]
    
    context = {
        'elons': page_obj,  # Sahifalashdan keyin
        'page_obj': page_obj,
        'categories': categories,
        'search_query': search_query,
        'selected_category': category,
        'selected_sort': sort_by,
    }
    
    return render(request, 'elon/elon_list.html', context)

# Barcha e'lonlar (eski versiya saqlanib qolgan bo'lsa)
def elons_list(request):
    """
    Eski versiya - yangi elon_list view'idan foydalaning
    """
    return elon_list(request)

@login_required
def elon_create(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        category = request.POST.get('category')
        if title and description and category:
            Elon.objects.create(user=request.user, title=title, description=description, category=category)
            messages.success(request, "E'lon muvaffaqiyatli yaratildi!")
            return redirect('elon_list')
        else:
            messages.error(request, "Barcha maydonlarni to'ldiring!")
    return render(request, 'elon/elon_form.html', {'action': 'create'})

@login_required
def elon_edit(request, id):
    elon = get_object_or_404(Elon, id=id)
    if request.user != elon.user and not request.user.is_superuser:
        return HttpResponseForbidden()
    if request.method == 'POST':
        elon.title = request.POST.get('title')
        elon.description = request.POST.get('description')
        elon.category = request.POST.get('category')
        elon.updated_at = timezone.now()
        elon.save()
        messages.success(request, "E'lon muvaffaqiyatli yangilandi!")
        return redirect('elon_list')
    return render(request, 'elon/elon_form.html', {'elon': elon, 'action': 'edit'})

@login_required
def elon_delete(request, id):
    elon = get_object_or_404(Elon, id=id)
    if request.user != elon.user and not request.user.is_superuser:
        return HttpResponseForbidden()
    if request.method == 'POST':
        elon.delete()
        messages.success(request, "E'lon muvaffaqiyatli o'chirildi!")
        return redirect('elon_list')
    return render(request, 'elon/elon_confirm_delete.html', {'elon': elon})

@login_required
def my_elons(request):
    """
    Foydalanuvchining o'z e'lonlari - qidiruv va sahifalash bilan
    """
    elons = Elon.objects.filter(user=request.user)
    
    # Qidiruv
    search_query = request.GET.get('search', '')
    if search_query:
        elons = elons.filter(
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    
    # Tartiblash
    elons = elons.order_by('-created_at')
    
    # Sahifalash
    paginator = Paginator(elons, 10)  # Har sahifada 10 ta e'lon
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'elons': page_obj,
        'page_obj': page_obj,
        'search_query': search_query,
        'is_my_elons': True,
    }
    
    return render(request, 'elon/elon_list.html', context)

@login_required
def elon_detail(request, id):
    elon = get_object_or_404(Elon, id=id)
    comments = elon.comments.select_related('user').order_by('created_at')
    elon.created_at_uz = elon.created_at.astimezone(UZ_TZ)
    for comment in comments:
        comment.created_at_uz = comment.created_at.astimezone(UZ_TZ)
    return render(request, 'elon/elon_detail.html', {'elon': elon, 'comments': comments})

@login_required
@require_POST
def add_comment(request, id):
    elon = get_object_or_404(Elon, id=id)
    text = request.POST.get('text')
    if text:
        Comment.objects.create(elon=elon, user=request.user, text=text)
        messages.success(request, "Izoh qo'shildi!")
    else:
        messages.error(request, "Izoh bo'sh bo'lishi mumkin emas!")
    return redirect(reverse('elon_detail', args=[elon.id]))

@login_required
def xizmatlar_list(request):
    """
    Xizmatlar ro'yxati - qidiruv va sahifalash bilan
    """
    services = Service.objects.all()
    
    # Qidiruv
    search_query = request.GET.get('search', '')
    if search_query:
        services = services.filter(
            Q(type__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    
    # Tartiblash
    services = services.order_by('-created_at')
    
    # Sahifalash
    paginator = Paginator(services, 8)  # Har sahifada 8 ta xizmat
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'services': page_obj,
        'page_obj': page_obj,
        'search_query': search_query,
    }
    
    return render(request, 'elon/xizmatlar_list.html', context)

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ['type', 'price', 'description', 'telegram_link', 'image']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

def admin_required(user):
    return user.is_superuser

@user_passes_test(admin_required)
def xizmat_qoshish(request):
    if request.method == 'POST':
        form = ServiceForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "Xizmat muvaffaqiyatli qo'shildi!")
            return redirect('xizmatlar_list')
        else:
            messages.error(request, "Forma xatolarini to'g'irlang!")
    else:
        form = ServiceForm()
    return render(request, 'elon/xizmat_qoshish.html', {'form': form})

@user_passes_test(admin_required)
def xizmat_tahrir(request, id):
    service = get_object_or_404(Service, id=id)
    if request.method == 'POST':
        form = ServiceForm(request.POST, request.FILES, instance=service)
        if form.is_valid():
            form.save()
            messages.success(request, "Xizmat muvaffaqiyatli yangilandi!")
            return redirect('xizmatlar_list')
        else:
            messages.error(request, "Forma xatolarini to'g'irlang!")
    else:
        form = ServiceForm(instance=service)
    return render(request, 'elon/xizmat_qoshish.html', {'form': form, 'edit_mode': True, 'service': service})

@user_passes_test(admin_required)
def xizmat_ochirish(request, id):
    service = get_object_or_404(Service, id=id)
    if request.method == 'POST':
        service.delete()
        messages.success(request, "Xizmat muvaffaqiyatli o'chirildi!")
        return redirect('xizmatlar_list')
    return redirect('xizmatlar_list')